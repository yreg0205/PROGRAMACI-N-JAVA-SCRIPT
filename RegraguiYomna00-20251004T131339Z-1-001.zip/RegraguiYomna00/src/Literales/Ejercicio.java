package Literales;

public class Ejercicio {

	public static void main(String[] args) {
		int edadNiño=12;
		final int velocidadLuz=300000;//Km/s
		final int Edadminima=10;
		String correo= "vaya@gmail.com";
		double pesoAtleta=40.44;
		final int mesesAño=12;
		char letraDNI='C';
		String telefono="887-44-42-12";
		long distanciaTierraSol=147_100_000_000L;//metros
		double distanciaLuzAño=9_460_740_478_580.8;
		
		
       
	}

}
