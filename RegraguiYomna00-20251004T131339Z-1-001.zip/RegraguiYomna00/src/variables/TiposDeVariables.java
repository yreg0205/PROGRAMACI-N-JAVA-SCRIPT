/*
 * Descripción: ejemplos de variables 
 * Autor:profe
 * Fecha:23/09/25
 */
package variables;

public class TiposDeVariables {

	public static void main(String[] args) {
		byte edadAlumno;//Declaración
		edadAlumno=0;//Incialización
       
		byte edadProfe= 0;//Declaración e incialización
	
	   System.out.print("Valor de la variable:" + edadAlumno);
        
	   double pesoAlumno, alturaAlumno;
	   pesoAlumno = 92.5;
	   alturaAlumno = 1.76;
	   System.out.println("Peso:" + pesoAlumno + "Altura: " + alturaAlumno);

	   pesoAlumno= 94;
	   System.out.println("Peso:"+ pesoAlumno + "\nAltura:" + alturaAlumno);
	   
	   char letraDni;
	   letraDni= 'B';
	   
	   String nombreAlumno;
	   nombreAlumno = "Yomna";
	   
	   boolean mayorEdad = false ;
 }

}

