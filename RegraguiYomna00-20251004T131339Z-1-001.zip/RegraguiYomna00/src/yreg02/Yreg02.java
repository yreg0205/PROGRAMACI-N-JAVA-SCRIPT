/*
 * Descripción:mostrar Hola mundo al usuario
 * Autor: Yomna Regragui 
 * Fecha:19/0972025
 */



package yreg02;

public class Yreg02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.out.println("Yomna Regragui");
	}

}
