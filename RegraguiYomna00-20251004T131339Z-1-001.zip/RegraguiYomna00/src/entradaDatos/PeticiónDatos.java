package entradaDatos;

import java.util.Scanner;



	public class PeticiónDatos {
		
		public static void main (String []args) {
			Scanner teclado=new Scanner (System.in);
			
			byte edadAlumno;
			System.out.print("Dame la edad del alumno : ");
			edadAlumno=teclado.nextByte();
			System.out.println("La edad del alumno es :"+edadAlumno);
			
			teclado.nextLine();//Después de pedir un valor numérico y antes de pedir un String 
			System.out.print("Dame tu nombre:");
			String nombreAlumno ;
			nombreAlumno= teclado.nextLine();
			System.out.println("El nombre es :" + nombreAlumno );
			
			double alturaAlumno;
			System.out.print("Dame la altura:");
			alturaAlumno = teclado.nextDouble();
			System.out.println("La altura es :"+ alturaAlumno );
			
			
		
	}
}
		
