/*
 * Descripción:mostrar Hola mundo al usuario
 * Autor: Yomna Regragui 
 * Fecha:19/09/2025
 */



package holamundo;

public class HolaMundo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hola,mundo");
		System.out.println("Mi primer programa de java");
			
		
	}

}
